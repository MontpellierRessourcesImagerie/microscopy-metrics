import numpy as np
from microscopy_metrics.fittingTools.fitting3D import Fitting3D
from microscopy_metrics.fittingTools.fitting3DRotation import Fitting3DRotation
from scratch.PSFGenerator.BornWolfPSF import BornWolfPSF
from scratch.PSFGenerator.Data3D import Data3D
import matplotlib

matplotlib.use("Qt5Agg")
import matplotlib.pyplot as plt

PSF_SIZE = 100
def generateBornWolfPSF():
    bw = BornWolfPSF()
    bw.nx = PSF_SIZE
    bw.ny = PSF_SIZE
    bw.nz = PSF_SIZE
    bw.resLateral = 50.0
    bw.resAxial = 50.0
    bw.NA = 1.4
    bw.lmbda = 500.0 * 1e-9
    bw.setParameters(ni=1.5, accuracy=0)
    bw.data = Data3D(bw.nx, bw.ny, bw.nz)
    
    bw.generate()
        
    zz = np.arange(PSF_SIZE)
    yy = np.arange(PSF_SIZE)
    xx = np.arange(PSF_SIZE)
    x, y, z = np.meshgrid(xx, yy, zz, indexing="ij")
    coords = np.stack([x.ravel(), y.ravel(), z.ravel()], -1)
    
    psf = bw.data.data.flatten()

    return psf

def savePSFAsTiff(psf, filename):
    from tifffile import imwrite
    psf_reshaped = psf.reshape((PSF_SIZE, PSF_SIZE, PSF_SIZE))
    imwrite(filename, psf_reshaped.astype(np.float32))

amp = 1.0
bg = 0.0
muX, muY, muZ = 50, 50, 50
sigma = 10
cxx, cxy, cxz = sigma**2, 0, 0
cyy, cyz, czz = sigma**2, 0, sigma**2

z = np.linspace(0, 100, 100)
y = np.linspace(0, 100, 100)
x = np.linspace(0, 100, 100)
Z, Y, X = np.meshgrid(z, y, x, indexing='ij')
coords = np.stack([Z.ravel(), Y.ravel(), X.ravel()], axis=-1)

gauss_func = Fitting3DRotation().gauss(amp,bg,muX,muY,muZ,10,5.0,5,0,np.deg2rad(45),np.deg2rad(75))
values = gauss_func(coords).reshape(X.shape)
savePSFAsTiff(values, "born_wolf_psf.tiff")

fig, axes = plt.subplots(2, 2, figsize=(12, 10))

axes[0, 0].contourf(X[50, :, :], Y[50, :, :], values[50, :, :], levels=20, cmap='viridis')
axes[0, 0].set_title("Coupe XY à Z=50")
axes[0, 0].set_xlabel("x")
axes[0, 0].set_ylabel("y")
axes[0, 0].set_aspect('equal')

axes[0, 1].contourf(X[:, 50, :], Z[:, 50, :], values[:, 50, :], levels=20, cmap='viridis')
axes[0, 1].set_title("Coupe XZ à Y=50")
axes[0, 1].set_xlabel("x")
axes[0, 1].set_ylabel("z")
axes[0, 1].set_aspect('equal')

axes[1, 0].contourf(Y[:, :, 50], Z[:, :, 50], values[:, :, 50], levels=20, cmap='viridis')
axes[1, 0].set_title("Coupe YZ à X=50")
axes[1, 0].set_xlabel("y")
axes[1, 0].set_ylabel("z")
axes[1, 0].set_aspect('equal')

axes[1, 1].plot(z, values[:, 50, 50], label=f"Profil en Z à X={muX}, Y={muY}")
axes[1, 1].axhline(0.5 * np.max(values[50, 50, :]), color='r', linestyle='--', label='Mi-hauteur')
axes[1, 1].set_title("Profil 1D en Z")
axes[1, 1].set_xlabel("z")
axes[1, 1].set_ylabel("Intensité")
axes[1, 1].legend()
axes[1, 1].grid(True)

plt.suptitle("Coupes 2D et Profil 1D de la Gaussienne 3D")
plt.tight_layout()
plt.show()
