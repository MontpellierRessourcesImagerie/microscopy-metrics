import matplotlib

import skimage.filters
import skimage.measure

from microscopy_metrics.scripts.PSFGenerator.PSF import *
from microscopy_metrics.scripts.evaluate_fitting import PSF_SIZE
matplotlib.use('Qt5Agg')
import matplotlib.pyplot as plt

def show2DPsf(psf, center):
    plt.imshow(psf[center], cmap="gray")
    plt.colorbar()
    plt.title("2D Image of a Gaussian")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.show()

imagePath = "/home/blangouet/Documents/template_napari/60x-Si-1.3-actual-banana/PSF_60x_Si_bague0.17_RT_actual_05.tif"
def getContourspoints(psf):
    points = []
    for i in range(psf.shape[0]):
        slice_2d = psf[i]
        image_th = skimage.filters.threshold_otsu(slice_2d)
        contours = skimage.measure.find_contours(slice_2d > image_th, level=0.5)
        for contour in contours:
            points.append([i,*contour])

    return points
def showXZContour(psf, y_center):
    # psf shape: (Z, Y, X)
    xz = psf[:, y_center, :]
    th = skimage.filters.threshold_otsu(xz)
    mask = xz > th
    contours = skimage.measure.find_contours(mask, level=0.5)

    plt.figure()
    plt.imshow(xz, cmap='gray', origin='lower')
    for contour in contours:
        # contour coords are (row=z, col=x)
        plt.plot(contour[:, 1], contour[:, 0], '-r', linewidth=1)
    plt.title(f'XZ slice at Y={y_center} with contours')
    plt.xlabel('X')
    plt.ylabel('Z')
    plt.colorbar()
    plt.show()
if __name__ == "__main__" :
    psf = PSFRandomParameter(size=PSF_SIZE, aberrationType="comatic").psf
    psfReshape = psf.reshape((PSF_SIZE, PSF_SIZE, PSF_SIZE))
    show2DPsf(psfReshape, int(PSF_SIZE / 2))
    points = getContourspoints(psfReshape)
    print(points)
    # show XZ slice with contour for the central Y
    showXZContour(psfReshape, int(PSF_SIZE / 2))


