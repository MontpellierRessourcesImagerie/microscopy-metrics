import matplotlib.pyplot as plt
import numpy as np
from skimage.io import imread
from microscopy_metrics.detectionTools.detection_tool import DetectionTool
from microscopy_metrics.thresholdTools.threshold_tool import Threshold
from skimage.filters import laplace, gaussian

output_dir = "/home/blangouet/Documents/perso/rapport/FDS/figures"


def extract_sub_image(image, center, size):
    z_center, y_center, x_center = center
    depth, height, width = size
    z_start = max(0, z_center - depth // 2)
    z_end = min(image.shape[0], z_center + depth // 2 + 1)
    y_start = max(0, y_center - height // 2)
    y_end = min(image.shape[1], y_center + height // 2 + 1)
    x_start = max(0, x_center - width // 2)
    x_end = min(image.shape[2], x_center + width // 2 + 1)
    return image[z_start:z_end, y_start:y_end, x_start:x_end]

def generate_high_passed_image_figure():
    image_path = "/home/blangouet/Documents/template_napari/40x-1.4-banana/40X_PSF_OIL_OLYMPUS_07.vsi - C488.tif"
    final_path = output_dir + "/high_passed_image.png"
    image = imread(image_path)
    image = extract_sub_image(image, center=(image.shape[0] // 2, int(image.shape[1] // 3 * 1.5), image.shape[2] // 3), size=(image.shape[0], image.shape[1] // 3, image.shape[2] // 3))
    detection = DetectionTool.getInstance("Centroids")
    detection._image = image
    detection._thresholdTool = Threshold.getInstance("otsu")
    detection.detect()
    gaussian_image = gaussian(image, sigma=2.0)
    high_passed_image = image - gaussian_image
    fig = plt.figure(figsize=(15, 5))
    ax1 = fig.add_subplot(1, 3, 1)
    ax1.imshow(np.max(image, axis=0), cmap="gray")
    ax1.set_title("Image originale")
    ax2 = fig.add_subplot(1, 3, 2)
    ax2.imshow(np.max(gaussian_image, axis=0), cmap="gray")
    ax2.set_title("Image gaussienne")
    ax3 = fig.add_subplot(1, 3, 3)
    ax3.imshow(np.max(high_passed_image, axis=0), cmap="gray")
    ax3.set_title("Image après filtrage passe-haut")
    plt.tight_layout()
    fig.savefig(final_path, dpi=300, bbox_inches="tight")
    plt.close(fig)

def generate_detection_localMaxima_figure():
    image_path = "/home/blangouet/Documents/template_napari/40x-1.4-banana/40X_PSF_OIL_OLYMPUS_07.vsi - C488.tif"
    final_path = output_dir + "/detection_localMaxima.png"
    image = imread(image_path)
    image = extract_sub_image(image, center=(image.shape[0] // 2, int(image.shape[1] // 3 * 1.5), image.shape[2] // 3), size=(image.shape[0], image.shape[1] // 3, image.shape[2] // 3))
    
    detection = DetectionTool.getInstance("peak local maxima")
    detection._image = image
    detection._thresholdTool = Threshold.getInstance("otsu")
    detection.detect()
    high_passed_image = detection._highPassedImage
    detected_peaks = detection._centroids
    fig = plt.figure(figsize=(10, 5))
    ax1 = fig.add_subplot(1, 2, 1)
    ax1.imshow(np.max(image, axis=0), cmap="gray")
    ax1.set_title("Image originale")
    ax3 = fig.add_subplot(1, 2, 2)
    ax3.imshow(np.max(image, axis=0), cmap="gray")
    ax3.set_title("centroids détectés")
    for peak in detected_peaks:
        idx = np.rint(peak).astype(int)
        if image.ndim == 3:
            _, y, x = idx
            ax3.scatter(x, y, s=15, c="cyan", marker="o", edgecolors="black", linewidths=0.5)
        else:
            y, x = idx
            ax3.scatter(x, y, s=15, c="cyan", marker="o", edgecolors="black", linewidths=0.5)
    plt.tight_layout()
    fig.savefig(final_path, dpi=300, bbox_inches="tight")
    plt.close(fig)

def generate_detection_centroids_figure():
    image_path = "/home/blangouet/Documents/template_napari/40x-1.4-banana/40X_PSF_OIL_OLYMPUS_07.vsi - C488.tif"
    final_path = output_dir + "/detection_centroids.png"

    # Charger et extraire une sous-image
    image = imread(image_path)
    image = extract_sub_image(
        image,
        center=(image.shape[0] // 2, int(image.shape[1] // 3 * 1.5), image.shape[2] // 3),
        size=(image.shape[0], image.shape[1] // 3, image.shape[2] // 3)
    )

    # Détection des centroids
    detection = DetectionTool.getInstance("Centroids")
    detection._image = image
    detection._thresholdTool = Threshold.getInstance("otsu")
    detection.detect()

    binary_image = detection.binaryImage
    labeled_image = detection.labeledImage
    detected_peaks = detection._centroids

    # Créer une figure 2x2
    fig = plt.figure(figsize=(12, 10))
    gs = fig.add_gridspec(2, 2)

    # Image originale
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.imshow(np.max(image, axis=0), cmap="gray")
    ax1.set_title("Image originale")

    # Image binaire
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.imshow(np.max(binary_image, axis=0), cmap="gray")
    ax2.set_title("Image binaire")

    # Image étiquetée (colorisée)
    ax3 = fig.add_subplot(gs[1, 0])
    # Utiliser une colormap adaptée pour les labels (ex: 'nipy_spectral', 'tab20', 'viridis')
    labeled_image_max = np.max(labeled_image, axis=0)
    ax3.imshow(labeled_image_max, cmap="nipy_spectral")  # Colormap pour distinguer les labels
    ax3.set_title("Image étiquetée (colorisée)")

    # Centroids détectés
    ax4 = fig.add_subplot(gs[1, 1])
    ax4.imshow(np.max(image, axis=0), cmap="gray")
    ax4.set_title("Centroids détectés")

    # Ajouter les centroids détectés
    for peak in detected_peaks:
        idx = np.rint(peak).astype(int)
        if image.ndim == 3:
            _, y, x = idx
            ax4.scatter(x, y, s=10, c="cyan", marker="o", edgecolors="black", linewidths=0.5)
        else:
            y, x = idx
            ax4.scatter(x, y, s=10, c="cyan", marker="o", edgecolors="black", linewidths=0.5)

    plt.tight_layout()
    fig.savefig(final_path, dpi=300, bbox_inches="tight")
    plt.close(fig)

    

def generate_detection_laplacianOfGaussian_figure():
    image_path = "/home/blangouet/Documents/template_napari/40x-1.4-banana/40X_PSF_OIL_OLYMPUS_07.vsi - C488.tif"
    final_path = output_dir + "/detection_laplacianOfGaussian.png"
    image = imread(image_path)
    image = extract_sub_image(image, center=(image.shape[0] // 2, int(image.shape[1] // 3 * 1.5), image.shape[2] // 3), size=(image.shape[0], image.shape[1] // 3, image.shape[2] // 3))
    detection = DetectionTool.getInstance("Laplacian of Gaussian")
    detection._image = image
    detection._thresholdTool = Threshold.getInstance("otsu")
    detection.detect()
    log_Image = laplace(gaussian(image, sigma=0.5))
    detected_peaks = detection._centroids
    fig = plt.figure(figsize=(15, 5))
    ax1 = fig.add_subplot(1, 3, 1)
    ax1.imshow(np.max(image, axis=0), cmap="gray")
    ax1.set_title("Image originale")
    ax2 = fig.add_subplot(1, 3, 2)
    ax2.imshow(np.max(log_Image, axis=0), cmap="gray")
    ax2.set_title("Image après filtrage Laplacien de Gaussienne")
    ax3 = fig.add_subplot(1, 3, 3)
    ax3.imshow(np.max(image, axis=0), cmap="gray")
    ax3.set_title("Centroids détectés")
    for peak in detected_peaks:
        idx = np.rint(peak).astype(int)
        if image.ndim == 3:
            _, y, x = idx
            ax3.scatter(x, y, s=10, c="cyan", marker="o", edgecolors="black", linewidths=0.5)
        else:
            y, x = idx
            ax3.scatter(x, y, s=10, c="cyan", marker="o", edgecolors="black", linewidths=0.5)
    plt.tight_layout()
    fig.savefig(final_path, dpi=300, bbox_inches="tight")
    plt.close(fig)

def generate_detection_differenceOfGaussian_figure():
    image_path = "/home/blangouet/Documents/template_napari/40x-1.4-banana/40X_PSF_OIL_OLYMPUS_07.vsi - C488.tif"
    final_path = output_dir + "/detection_differenceOfGaussian.png"
    image = imread(image_path)
    image = extract_sub_image(image, center=(image.shape[0] // 2, int(image.shape[1] // 3 * 1.5), image.shape[2] // 3), size=(image.shape[0], image.shape[1] // 3, image.shape[2] // 3))
    detection = DetectionTool.getInstance("Difference of Gaussian")
    detection._image = image
    detection._thresholdTool = Threshold.getInstance("otsu")
    detection.detect()
    dog_Image = gaussian(image, sigma=0.5) - gaussian(image, sigma=1.0)
    detected_peaks = detection._centroids
    fig = plt.figure(figsize=(15, 5))
    ax1 = fig.add_subplot(1, 3, 1)
    ax1.imshow(np.max(image, axis=0), cmap="gray")
    ax1.set_title("Image originale")
    ax2 = fig.add_subplot(1, 3, 2)
    ax2.imshow(np.max(dog_Image, axis=0), cmap="gray")
    ax2.set_title("Image après filtrage Difference de Gaussienne")
    ax3 = fig.add_subplot(1, 3, 3)
    ax3.imshow(np.max(image, axis=0), cmap="gray")
    ax3.set_title("Centroids détectés")
    for peak in detected_peaks:
        idx = np.rint(peak).astype(int)
        if image.ndim == 3:
            _, y, x = idx
            ax3.scatter(x, y, s=10, c="cyan", marker="o", edgecolors="black", linewidths=0.5)
        else:
            y, x = idx
            ax3.scatter(x, y, s=10, c="cyan", marker="o", edgecolors="black", linewidths=0.5)
    plt.tight_layout()
    fig.savefig(final_path, dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    generate_high_passed_image_figure()
    generate_detection_localMaxima_figure()
    generate_detection_centroids_figure()
    generate_detection_laplacianOfGaussian_figure()
    generate_detection_differenceOfGaussian_figure()