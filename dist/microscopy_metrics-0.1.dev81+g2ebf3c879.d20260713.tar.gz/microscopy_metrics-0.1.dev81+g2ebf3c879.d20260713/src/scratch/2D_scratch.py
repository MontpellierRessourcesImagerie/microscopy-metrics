import numpy as np
import matplotlib.pyplot as plt

def gauss_2d(amp, bg, muX, muY, cxx, cxy, cyy):
    def fun(coords):
        covInv = np.linalg.inv(np.array([[cxx, cxy], [cxy, cyy]]))
        exponent = -0.5 * (
            covInv[0, 0] * (coords[:, 0] - muX) ** 2
            + 2 * covInv[0, 1] * (coords[:, 0] - muX) * (coords[:, 1] - muY)
            + covInv[1, 1] * (coords[:, 1] - muY) ** 2
        )
        return amp * np.exp(exponent) + bg
    return fun

def addMicroscopyNoise(image, maxPhotons=100, readoutNoiseStd=5.0):
    scaledImage = (image / np.max(image)) * maxPhotons
    noisyPoisson = np.random.poisson(scaledImage).astype(np.float32)
    gaussianNoise = np.random.normal(0, readoutNoiseStd, size=image.shape)
    finalNoisyImage = noisyPoisson + gaussianNoise
    finalNoisyImage = np.minimum(np.maximum(finalNoisyImage, 0),maxPhotons)
    return finalNoisyImage

amp = 1.0
bg = 0.0
muX, muY = 50, 50
sigma = 10
cxx, cxy, cyy = sigma**2, 0, sigma**2

x = np.linspace(0, 100, 1000)
y = np.linspace(0, 100, 1000)
X, Y = np.meshgrid(x, y)
coords = np.stack([X.ravel(), Y.ravel()], axis=-1)

gauss_func = gauss_2d(amp, bg, muX, muY, cxx, cxy, cyy)
psf = addMicroscopyNoise(gauss_func(coords))
Z = psf.reshape(X.shape)

plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.contourf(X, Y, Z, levels=20, cmap='grey')
plt.colorbar(label='Intensité')
plt.title("Gaussienne 2D")
plt.xlabel("x")
plt.ylabel("y")
plt.legend()
plt.grid(False)

plt.subplot(1, 2, 2)
profile_x = Z[50, :]
x_profile = x
plt.plot(x_profile, profile_x, label=f"Profil en X à Y={muY}")
plt.axhline(0.5 * np.max(profile_x), color='r', linestyle='--', label='Mi-hauteur')
plt.title("Profil 1D en X")
plt.xlabel("x")
plt.ylabel("Intensité")
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.show()
