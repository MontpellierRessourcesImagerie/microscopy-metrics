import numpy as np
from microscopy_metrics.detectionTools.detection_tool import DetectionTool
from microscopy_metrics.thresholdTools.threshold_tool import Threshold
from microscopy_metrics.scripts.evaluate_fitting import generateBornWolfPSF, PSF_SIZE

def multiplePeak(image):
    for y in range(image.shape[1]):
        img = image[:,y,:]
        detectionTool = DetectionTool.getInstance("Laplacian of Gaussian")
        detectionTool._image = img
        detectionTool._thresholdTool = Threshold.getInstance("legacy")
        detectionTool.detect()
        if len(detectionTool._centroids) > 1:
            print(detectionTool._centroids)

if __name__ == "__main__":
    psf, coords, fwhm = generateBornWolfPSF()
    psfReshape = psf.reshape((PSF_SIZE, PSF_SIZE, PSF_SIZE))
    multiplePeak(psfReshape)
