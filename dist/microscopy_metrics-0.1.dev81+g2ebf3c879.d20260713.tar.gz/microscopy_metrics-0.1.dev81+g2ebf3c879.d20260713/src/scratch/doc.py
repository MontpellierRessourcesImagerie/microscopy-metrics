
from microscopy_metrics.scripts.PSFGenerator.PSF import PSFRandomParameter, PSFGenerator
path = "path/to/your/result/folder"

#To generate a PSF without aberration
psf = PSFRandomParameter()

#To generate a PSF with comatic aberration
psf = PSFRandomParameter(aberrationType="comatic")

#To generate a PSF with astigmatism
psf = PSFRandomParameter(aberrationType="astigmatism")

#To generate a PSF with spherical aberration
psf = PSFRandomParameter(aberrationType="spherical")

#To generate a PSF with no random parameters
psf = PSFGenerator()


import numpy as np
from microscopy_metrics.detection import Detection
from microscopy_metrics.thresholdTools.threshold_tool import Threshold
from microscopy_metrics.detectionTools.detection_tool import DetectionTool


detector = Detection()
detector.image = psf.psf
detectionTool = DetectionTool.getInstance("Centroids")
detectionTool._image = psf.psf
detectionTool._thresholdTool = Threshold.getInstance("legacy")
detector._detectionTool = detectionTool
detector.cropFactor = 5
detector.beadSize = 0.2
detector.rejectionDistance = 0.5
detector.pixelSize = np.array([psf.dz,psf.dxy,psf.dxy])
for _ in detector.run(outputDir=path):
        pass
imageAnalyzer = detector._imageAnalyzer
imageAnalyzer._path = path

import os
from microscopy_metrics.metrics import Metrics
from microscopy_metrics.resolutionTools.theoretical_resolution import TheoreticalResolution

MetricTool = Metrics()
MetricTool._imageAnalyzer = imageAnalyzer
MetricTool._ringInnerDistance = 1.0
MetricTool._ringThickness = 2.0
MetricTool._TheoreticalResolutionTool = TheoreticalResolution.getInstance("widefield")
MetricTool._TheoreticalResolutionTool._numericalAperture = psf.NA
MetricTool._TheoreticalResolutionTool._emissionWavelength = psf.wvl
MetricTool._TheoreticalResolutionTool._refractiveIndex = psf.ni
MetricTool._TheoreticalResolutionTool._excitationWavelength = 0.488
for _ in MetricTool.runPrefittingMetrics():
        pass
for bead in imageAnalyzer._beadAnalyzer:
	if bead._rejected == False and bead._roi is not None and bead._metricTool.meshBuilder is not None:
		bead._metricTool.meshBuilder.saveMesh(os.path.join(path, f"bead_{bead._id}_mesh.obj")) 

from microscopy_metrics.fitting import Fitting

FittingTool = Fitting()
FittingTool._imageAnalyzer = imageAnalyzer
FittingTool.fitType = "2D"
FittingTool._thresholdRSquared = 0.5
FittingTool.computeFitting()

MetricTool._imageAnalyzer = FittingTool._imageAnalyzer
for _ in MetricTool.runMetrics():
	pass
imageAnalyzer = MetricTool._imageAnalyzer

from microscopy_metrics.report_generator import ReportGenerator

detector.cropPsf(path)
detector.GlobalCropPsf(path)
MetricTool.GenerateHeatmap(path)
FittingTool.displayFitting(path)
ReportGenerator = ReportGenerator().getInstance("HTML")
ReportGenerator._inputDir = path
ReportGenerator._imageAnalyzer = imageAnalyzer
ReportGenerator.generateReport(path)