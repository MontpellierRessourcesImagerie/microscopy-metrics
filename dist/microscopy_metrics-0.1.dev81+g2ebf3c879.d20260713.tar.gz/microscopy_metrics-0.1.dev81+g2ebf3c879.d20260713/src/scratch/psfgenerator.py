import psfmodels as psfm
import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import map_coordinates

from microscopy_metrics.scripts.PSFGenerator.PSF import PSFGenerator, PSFWithComaticAberration, PSFWithAstigmatismAberration, PSFWithSphericalAberration, PSFRandomParameter


def generate_PSF_comatic_aberration(intensity=0.05):
    """
    Generate a PSF with comatic aberration.
    """
    shape = (31, 31, 31)
    z, y, x = np.mgrid[0:shape[0], 0:shape[1], 0:shape[2]]
    zC, yC, xC = np.array(shape) // 2
    psf_base = psfm.make_psf(shape[1], shape[2], dxy=0.05, dz=0.05, pz=0, 
                             ni0=1.515, ni=1.515, wvl=0.5, NA=1.4)
    psf_base = np.asarray(psf_base)
    xShift = ((z - zC) ** 2) * intensity
    xRenseigne = x - xShift
    psf_banane = map_coordinates(psf_base, [z, y, xRenseigne], order=1)
    return psf_banane

def generate_PSF_astigmatism_aberration(intensity=0.05):
    shape = (31, 31, 31)
    z, y, x = np.mgrid[0:shape[0], 0:shape[1], 0:shape[2]]
    zC, yC, xC = np.array(shape) // 2
    psf_base = psfm.make_psf(shape[1], shape[2], dxy=0.05, dz=0.05, pz=0, 
                             ni0=1.515, ni=1.515, wvl=0.5, NA=1.4)
    psf_base = np.asarray(psf_base)
    stretchFactor = ((z - zC)) * intensity
    xScale = (x - xC) * np.exp(stretchFactor)
    yScale = (y - yC) * np.exp(-stretchFactor)
    xRenseigne = xC + xScale
    yRenseigne = yC + yScale
    psf_astigmatism = map_coordinates(psf_base, [z, yRenseigne, xRenseigne], order=1)
    return psf_astigmatism

def generate_PSF_spherical_aberration():
    psf = psfm.make_psf(127,127,dxy=0.05,dz=0.05,pz=0, ni0=1.515, ni=1.500, wvl=0.5, NA=1.4)
    return psf

if __name__ == "__main__":
    psf = PSFGenerator()
    psf.showPSF()
    psf_comatic = PSFWithComaticAberration()
    psf_comatic.showPSF()
    psf_astigmatism = PSFWithAstigmatismAberration()
    psf_astigmatism.showPSF()
    psf_spherical = PSFWithSphericalAberration()
    psf_spherical.showPSF()
    psf_random = PSFRandomParameter(aberrationType="comatic")
    psf_random.showPSF()