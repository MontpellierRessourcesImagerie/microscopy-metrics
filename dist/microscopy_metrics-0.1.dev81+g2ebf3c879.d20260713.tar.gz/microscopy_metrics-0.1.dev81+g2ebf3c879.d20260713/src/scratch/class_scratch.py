class test1(object):
    def __init__(self, cpt = 0):
        self._cpt = cpt

class test2(object):
    
    def add(self,test:test1):
        test._cpt += 1

if __name__ == "__main__":
    test = test1(0)
    testbis = test2()
    testbis.add(test)
    print(test._cpt)
    test._cpt = 10
    testbis.add(test)
    print(test._cpt)

