import numpy as np
import matplotlib.pyplot as plt

def gauss(x, amp, bg, mu, sigma):
    print(sigma)
    return amp * np.exp(-(x - mu)**2 / (2 * sigma**2)) + bg

amp = 1.0
bg = 0.0
mu = 50
sigma = 10

x = np.linspace(0, 100, 500)

y = gauss(x, amp, bg, mu, sigma)

plt.figure(figsize=(10, 6))
plt.plot(x, y, label=f"Gaussienne (amp={amp}, bg={bg}, mu={mu}, sigma={sigma})")
plt.axvline(x=mu, color='r', linestyle='--', label=f'Centre (mu={mu})')
plt.axhline(y=amp/2, color='g', linestyle=':', label='Mi-hauteur')

fwhm = 2 * np.sqrt(2 * np.log(2)) * sigma
plt.axvline(x=mu - fwhm/2, color='g', linestyle=':')
plt.axvline(x=mu + fwhm/2, color='g', linestyle=':')

plt.title("Courbe Gaussienne")
plt.xlabel("x")
plt.ylabel("Intensité")
plt.legend()
plt.grid(True)
plt.show()

print(f"FWHM: {fwhm}")
