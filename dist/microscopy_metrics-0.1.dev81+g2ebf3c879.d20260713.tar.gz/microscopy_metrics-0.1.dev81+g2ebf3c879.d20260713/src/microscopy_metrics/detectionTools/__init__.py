__all__ = [
    "PeakLocalMaxDetector"
]
