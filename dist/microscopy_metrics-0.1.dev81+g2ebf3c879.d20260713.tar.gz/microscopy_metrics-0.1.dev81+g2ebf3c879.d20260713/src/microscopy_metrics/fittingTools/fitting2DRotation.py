import os
import math
import numpy as np
import matplotlib
import warnings

matplotlib.use("Agg")
from matplotlib import pyplot as plt

from scipy.optimize import curve_fit, OptimizeWarning
from scipy.spatial.transform import Rotation as SciRot


from microscopy_metrics.fittingTools.fittingTool import FittingTool
from microscopy_metrics.fittingTools.fitting3DRotation import Fitting3DRotation
from microscopy_metrics.fittingTools.fitting1D import Fitting1D
from microscopy_metrics.utils import pxToUm

warnings.filterwarnings("error", category=OptimizeWarning)


class Fitting2DRotation(FittingTool):
    """Class for fitting a 2D Gaussian curve with rotation to the PSF profile of a microscopy image.
    This class inherits from the FittingTool base class and implements methods specific to 2D Gaussian fitting with rotation.
    It includes methods for evaluating the Gaussian function, fitting the curve to the data, and plotting the results.
    """

    name = "2D rotation"

    def __init__(self):
        super().__init__()
        self.thetas = [0, 0, 0]

    def gauss(
        self,
        amp: float,
        bg: float,
        muX: float,
        muY: float,
        sigmaX: float,
        sigmaY: float,
        theta: float,
    ):
        """Generates a 2D Gaussian function with rotation based on the provided parameters.
        
        Args:
            amp (float): amplitude of the curve
            bg (float): background intensity
            muX,muY (float): center coordinates of the Gaussian
            sigmaX,sigmaY (float): standard deviation of the Gaussian
            theta (float): rotation angle in radians
        
        Returns:
            float: Intensity value at (x,y) following the curve
        """

        def fun(coords):
            x = coords[:, 0]
            y = coords[:, 1]
            x_rot = (x - muX) * np.cos(theta) - (y - muY) * np.sin(theta)
            y_rot = (x - muX) * np.sin(theta) + (y - muY) * np.cos(theta)
            exponent = -((x_rot**2) / (2 * sigmaX**2) + (y_rot**2) / (2 * sigmaY**2))
            return bg + (amp - bg) * np.exp(exponent)

        return fun

    def evalFun(
        self,
        x: np.ndarray,
        amp: float,
        bg: float,
        muX: float,
        muY: float,
        sigmaX: float,
        sigmaY: float,
        theta: float,
    ):
        """Evaluates the 2D Gaussian function with rotation at the given x values.
        
        Args:
            x (np.ndarray): The x values at which to evaluate the function.
            amp (float): amplitude of the curve
            bg (float): background intensity
            muX,muY (float): center coordinates of the Gaussian
            sigmaX,sigmaY (float): standard deviation of the Gaussian
            theta (float): rotation angle in radians
        
        Returns:
            float: Intensity value at (x,y) following the curve
        """
        return self.gauss(
            amp=amp, bg=bg, muX=muX, muY=muY, sigmaX=sigmaX, sigmaY=sigmaY, theta=theta
        )(x)

    def fitCurve(
        self,
        amp: float,
        bg: float,
        mu: list,
        sigma: list,
        theta: float,
        coords: np.ndarray,
        psf: np.ndarray,
    ):
        """Fits the 2D Gaussian function with rotation to the provided PSF data using curve fitting.
        
        Args:
            amp (float): amplitude of the Gaussian
            bg (float): background intensity
            mu (List(float)): center of the Gaussian
            sigma (List(float)): standard deviation of the Gaussian
            theta (float): rotation angle in radians
            coords (np.array(float)): List of X,Y coordinates
            psf (np.ndarray): 1D image of the flatten 2D psf
        
        Raises:
            RuntimeError: If the optimization fails to converge.
        
        Returns:
            List(float),Matrix(float): List of fitted parameters and covariance matrix
        """
        params = [amp, bg, *mu, *sigma, theta]
        try:
            popt, pcov = curve_fit(
                self.evalFun,
                coords,
                psf.ravel(),
                p0=params,
                maxfev=20000,
                bounds=(
                    [0, -np.inf, 0, 0, 1e-6, 1e-6, -np.pi - 1e-6],
                    [
                        np.inf,
                        np.inf,
                        psf.shape[0],
                        psf.shape[1],
                        psf.shape[0],
                        psf.shape[1],
                        np.pi + 1e-6,
                    ],
                ),
            )
        except Exception as e:
            print(
                f"Fitting2DRotation Optimization warning: {e}. Returning initial parameters."
            )
            popt = params
            pcov = np.zeros((len(params), len(params)))
            self._commentary += f"Fitting2DRotation Optimization warning. Returning initial parameters (Fitting1D).\n"
        return popt, pcov

    def showFit(self, outputPath: str):
        """Plots the fitted 2D Gaussian curve with rotation against the original PSF data for all three axes.
        
        Args:
            outputPath (str): Directory where the plots will be saved.
        """
        center = self.getLocalCentroid()
        psf = self._image.astype(np.float64)
        fitShapeZ = min(psf.shape[0] * 5, 256)
        fitShapeY = min(psf.shape[1] * 5, 128)
        fitShapeX = min(psf.shape[2] * 5, 128)
        zz_fine = np.linspace(0, psf.shape[0], fitShapeZ)
        yy_fine = np.linspace(0, psf.shape[1], fitShapeY)
        xx_fine = np.linspace(0, psf.shape[2], fitShapeX)
        z_fine, y_fine, x_fine = np.meshgrid(zz_fine, yy_fine, xx_fine, indexing="ij")
        fine_coords_zyx = np.stack([z_fine.ravel(), y_fine.ravel(), x_fine.ravel()], -1)
        z0 = self.parameters[2] * (fitShapeZ / psf.shape[0])
        y0 = self.parameters[3] * (fitShapeY / psf.shape[1])
        x0 = self.parameters[4] * (fitShapeX / psf.shape[2])
        L = min(max(psf.shape) * 5 / 4, 30)
        thetaX = self.thetas[2]
        thetaY = self.thetas[1]
        thetaZ = self.thetas[0]
        rot = SciRot.from_euler("zyx", [thetaZ, thetaY, thetaX])
        R = rot.as_matrix()
        sigma2 = np.diag(
            [self.parameters[7] ** 2, self.parameters[6] ** 2, self.parameters[5] ** 2]
        )
        cov = R @ sigma2 @ R.T
        eigvals, eigvecs = np.linalg.eigh(cov)
        majorIDX = np.argmax(eigvals)
        majorAxis = eigvecs[:, majorIDX]
        anisotropy = np.sqrt(eigvals[majorIDX] / np.min(eigvals))
        hasMajorAxis = anisotropy > 1.15
        L = min(max(psf.shape) * 5 / 4, 30)
        params = [*self.parameters, *self.thetas]
        fit = Fitting3DRotation().gauss(*params)(fine_coords_zyx)
        fit = fit.reshape((fitShapeZ, fitShapeY, fitShapeX))
        fig = plt.figure(figsize=(10, 5))
        ax2 = fig.add_subplot(1, 2, 2)
        centerFit = int(fitShapeZ * (center[0] / psf.shape[0]))
        ax2.imshow(fit[centerFit], cmap="viridis", origin="upper")
        ax2.set_title(f"Fit YX - angle {self.thetas[0]:.2f} rad")
        ax2.axis("off")
        proj_yx = np.array([majorAxis[0], majorAxis[1]])
        norm_yx = np.linalg.norm(proj_yx)
        if hasMajorAxis and norm_yx > 1e-6:
            dir_yx = proj_yx / norm_yx
            dx_yx, dy_yx = L * dir_yx
            ax2.plot(
                [x0 - dx_yx, x0 + dx_yx],
                [y0 + dy_yx, y0 - dy_yx],
                color="red",
                linewidth=2,
            )
            ax2.scatter([x0], [y0], color="red", alpha=0.7)
        ax2.axhline(y=fitShapeY / 2, color="k", alpha=0.5, linestyle="--")
        ax2.axvline(x=fitShapeX / 2, color="k", alpha=0.5, linestyle="--")
        ax2.xaxis.set_inverted(True)
        plt.tight_layout()
        fig.savefig(
            os.path.join(outputPath, "2D_Gaussian_Image_YX.png"),
            dpi=300,
            bbox_inches="tight",
        )
        plt.close(fig)
        fig2 = plt.figure(figsize=(10, 5))
        ax2 = fig2.add_subplot(1, 2, 2)
        centerFit = int(fitShapeY * (center[1] / psf.shape[1]))
        ax2.imshow(fit[:, centerFit, :], cmap="viridis", origin="upper")
        ax2.set_title(f"Fit XZ - Pitch: {self.thetas[1]:.2f} rad")
        proj_xz = np.array([majorAxis[0], majorAxis[2]])
        norm_xz = np.linalg.norm(proj_xz)
        if hasMajorAxis and norm_xz > 1e-6:
            dir_xz = proj_xz / norm_xz
            dx_xz, dz_xz = L * dir_xz
            ax2.plot(
                [x0 - dx_xz, x0 + dx_xz],
                [z0 + dz_xz, z0 - dz_xz],
                color="red",
                linewidth=2,
            )
        ax2.scatter([x0], [z0], color="red", alpha=0.7)
        ax2.axhline(y=fitShapeZ / 2, color="k", alpha=0.5, linestyle="--")
        ax2.axvline(x=fitShapeX / 2, color="k", alpha=0.5, linestyle="--")
        ax2.axis("off")
        ax2.xaxis.set_inverted(True)
        plt.tight_layout()
        fig2.savefig(
            os.path.join(outputPath, "2D_Gaussian_Image_XZ.png"),
            dpi=300,
            bbox_inches="tight",
        )
        plt.close(fig2)
        fig3 = plt.figure(figsize=(10, 5))
        ax2 = fig3.add_subplot(1, 2, 2)
        centerFit = int(fitShapeX * (center[2] / psf.shape[2]))
        ax2.imshow(fit[:, :, centerFit], cmap="viridis", origin="upper")
        ax2.set_title(f"Fit ZY - Roll: {self.thetas[2]:.2f} rad")
        proj_zy = np.array([majorAxis[1], majorAxis[2]])
        norm_zy = np.linalg.norm(proj_zy)
        if hasMajorAxis and norm_zy > 1e-6:
            dir_zy = proj_zy / norm_zy
            dy_zy, dz_zy = L * dir_zy
            ax2.plot(
                [y0 - dy_zy, y0 + dy_zy],
                [z0 + dz_zy, z0 - dz_zy],
                color="red",
                linewidth=2,
            )
        ax2.scatter([y0], [z0], color="red", alpha=0.7)
        ax2.axhline(y=fitShapeZ / 2, color="k", alpha=0.5, linestyle="--")
        ax2.axvline(x=fitShapeY / 2, color="k", alpha=0.5, linestyle="--")
        ax2.axis("off")
        ax2.xaxis.set_inverted(True)
        plt.tight_layout()
        fig3.savefig(
            os.path.join(outputPath, "2D_Gaussian_Image_ZY.png"),
            dpi=300,
            bbox_inches="tight",
        )
        plt.close(fig3)

    def plotSingleFit(
        self,
        coords: np.ndarray,
        psf: np.ndarray,
        fineCoords: np.ndarray,
        fit2D: np.ndarray,
        outputPath: str,
        index: int,
    ):
        """Plots the original data points, the fitted curve, and key parameters for a single axis.
       
        Args:
            coords (array): Coordinates of the data points.
            psf (array): Intensity values at the data points.
            fineCoords (array): Coordinates for plotting the fitted curve.
            fit2D (array): Intensity values of the 2D fit at the fine coordinates.
            outputPath (str): Directory where the plot will be saved.
            index (int): Index of the axis being plotted (0 for Z, 1 for Y, 2 for X).
        """
        params = [
            self.params1D[0],
            self.params1D[1],
            self.params1D[2 + index],
            self.params1D[5 + index],
        ]
        fit1D = Fitting1D().gauss(*params)(fineCoords)
        yLim = [0.0, psf.max() * 1.1]
        fig1, ax1 = plt.subplots(figsize=(7, 5))
        ax1.plot(coords, psf, "-", label="PSF", color="k")
        ax1.scatter(coords, psf, color="k", alpha=0.5, label="measurement points")
        ax1.plot(fineCoords, fit1D, label="1D Curve Fit")
        halfMax = (fit1D.max() + fit1D.min()) / 2.0
        ax1.axhline(
            y=halfMax, color="g", linestyle="--", alpha=0.7, label="FWHM 1D fit"
        )
        ax1.plot(fineCoords, fit2D, label="2D Curve Fit")
        halfMax = (fit2D.max() + fit2D.min()) / 2.0
        ax1.axhline(
            y=halfMax, color="r", linestyle="--", alpha=0.7, label="FWHM 2D fit"
        )
        ax1.axhline(
            y=self.parameters[0],
            color="orange",
            linestyle="dotted",
            alpha=0.5,
            label=f"Amplitude: {self.parameters[0]:.2f}",
        )
        ax1.axvline(
            x=self.parameters[2 + index],
            color="purple",
            linestyle="dotted",
            alpha=0.5,
            label=f"Mu: {self.parameters[2+index]:.2f}",
        )
        ax1.plot(self.parameters[2 + index], self.parameters[0], "ko")
        ax1.set_ylim(yLim)
        ax1.set_title(f"{self.axes[index]} Profile")
        ax1.legend()
        ax1.set_xlabel("pixel")
        ax1.set_ylabel("Intensity")
        fig1.savefig(
            os.path.join(outputPath, f"fit_curve_1D_{self.axes[index]}.png"),
            dpi=300,
            bbox_inches="tight",
        )
        plt.close(fig1)

    def plotFit(self, outputPath: str):
        """Plots the fitted 2D Gaussian curve in 3D.
        
        Args:
            outputPath (str): Directory where the plot will be saved.
        """
        psf = self._image.astype(np.float64)
        p = self.parameters
        params2D = [
            [p[0], p[1], p[2], p[3], p[5], p[6], self.thetas[0]],
            [p[0], p[1], p[3], p[4], p[6], p[7], self.thetas[1]],
            [p[0], p[1], p[2], p[4], p[5], p[7], self.thetas[2]],
        ]
        center = self.getLocalCentroid()
        psfs = [
            psf[:, center[1], center[2]],
            psf[center[0], :, center[2]],
            psf[center[0], center[1], :],
        ]
        for i in range(3):
            coords = np.arange(psf.shape[i])
            fine = np.linspace(0, psf.shape[i] - 1, 100)
            if i < 2:
                index = i + 1
                fineCoords = np.column_stack((fine, np.full_like(fine, center[index])))
            else:
                index = 0
                fineCoords = np.column_stack((np.full_like(fine, center[index]), fine))
            self.plotSingleFit(
                coords,
                psfs[i],
                fine,
                self.gauss(*params2D[i])(fineCoords),
                outputPath,
                i,
            )

    def getCoords(self, psf: np.ndarray):
        """Generates an array of coordinates corresponding to the shape of the PSF image, suitable for use in the 2D fitting process.
        
        Args:
            psf (np.ndarray): 2D image to process for coordinate generation
        
        Returns:
            np.ndarray: Coordinates for the 2D fit
        """
        y, x = np.indices(psf.shape)
        return np.stack([y.ravel(), x.ravel()], axis=-1)

    def processSingleFit(self, index: int):
        """Processes a single fit for the given index, performing fitting, and plotting.
        
        Args:
            index (int): ID of the PSF and position in lists where results are stored.
        """
        imageFloat = self._image.astype(np.float64)
        physic = self.getLocalCentroid()
        psf = [
            imageFloat[:, :, physic[2]],
            imageFloat[physic[0], :, :],
            imageFloat[:, physic[1], :],
        ]
        axe = ["ZY", "YX", "XZ"]
        coords = [
            self.getCoords(psf[0]),
            self.getCoords(psf[1]),
            self.getCoords(psf[2]),
        ]
        self.compute1DParams()
        visual_angles = []
        amp = self.params1D[0]
        bg = self.params1D[1]
        for u in range(3):
            u2 = (u + 1) % 3
            if u < 2:
                sigma = [self.params1D[5 + u], self.params1D[5 + u2]]
                mu = [self.params1D[2 + u], self.params1D[2 + u2]]
            else:
                sigma = [self.params1D[5 + u2], self.params1D[5 + u]]
                mu = [self.params1D[2 + u2], self.params1D[2 + u]]
            params, pcov = self.fitCurve(amp, bg, mu, sigma, 0, coords[u], psf[u])
            self.parameters[0] += params[0] / 3.0
            self.parameters[1] += params[1] / 3.0
            self.thetas[u] = params[6]
            if params[4] > params[5]:
                angle_app = math.degrees(
                    math.atan2(np.cos(params[6]), -np.sin(params[6]))
                )
            else:
                angle_app = math.degrees(
                    math.atan2(np.sin(params[6]), np.cos(params[6]))
                )
            visual_angles.append(angle_app)

            if u < 2:
                self.parameters[2 + u] += params[2] / 2.0
                self.parameters[2 + u2] += params[3] / 2.0
                self.parameters[5 + u] += params[4] / 2.0
                self.parameters[5 + u2] += params[5] / 2.0
                self.fwhms[u] += pxToUm(self.fwhm(params[4]), self._spacing[u]) / 2.0
                self.fwhms[u2] += pxToUm(self.fwhm(params[5]), self._spacing[u2]) / 2.0
            else:
                self.parameters[2 + u] += params[3] / 2.0
                self.parameters[2 + u2] += params[2] / 2.0
                self.parameters[5 + u] += params[5] / 2.0
                self.parameters[5 + u2] += params[4] / 2.0
                self.fwhms[u] += pxToUm(self.fwhm(params[5]), self._spacing[u]) / 2.0
                self.fwhms[u2] += pxToUm(self.fwhm(params[4]), self._spacing[u2]) / 2.0
            self.uncertainties[u] = self.uncertainty(pcov)
            self.determinations[u] = self.determination(
                params, coords[u], psf[u].flatten()
            )
            self.pcovs[u] = pcov
