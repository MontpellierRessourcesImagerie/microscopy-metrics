import os
import numpy as np
import math
import matplotlib
import warnings

matplotlib.use("Agg")
from matplotlib import pyplot as plt

from scipy.optimize import curve_fit, OptimizeWarning

from microscopy_metrics.fittingTools.fittingTool import FittingTool
from microscopy_metrics.fittingTools.fitting1D import Fitting1D
from microscopy_metrics.utils import pxToUm

warnings.filterwarnings("error", category=OptimizeWarning)


class Fitting2DEllips(FittingTool):
    """Class for fitting a 2D Ellipse Gaussian to the PSF profile of a microscopy image.
    This class inherits from the FittingTool base class and implements methods specific to 2D Ellipse Gaussian fitting.
    It includes methods for evaluating the 2D Ellipse Gaussian function, fitting the curve to the data, and plotting the results.
    """

    name = "2D Ellipse"

    def __init__(self):
        super().__init__()
        self.thetas = [0, 0, 0]

    def gauss(
        self,
        amp: float,
        bg: float,
        muX: float,
        muY: float,
        a: float,
        b: float,
        c: float,
    ):
        """Generates a 2D Ellipse Gaussian function based on the provided parameters.
        
        Args:
            amp (float): amplitude of the curve
            bg (float): background intensity
            muX,muY (float): center coordinates of the Gaussian
            a,b,c (float): coefficients for the ellipse
        
        Returns:
            float: Intensity value at (x,y) following the curve
        """

        def fun(coords: np.ndarray):
            exponent = (
                (a * ((coords[:, 0] - muX) ** 2))
                + (c * ((coords[:, 1] - muY) ** 2))
                + (2.0 * b * (coords[:, 0] - muX) * (coords[:, 1] - muY))
            )
            return bg + (amp - bg) * np.exp(-exponent)

        return fun

    def evalFun(
        self,
        x: np.ndarray,
        amp: float,
        bg: float,
        muX: float,
        muY: float,
        a: float,
        b: float,
        c: float,
    ):
        """calculates the 2D Ellipse Gaussian function at the given x values.
        
        Args:
            amp (float): amplitude of the curve
            bg (float): background intensity
            muX,muY (float): center coordinates of the Gaussian
            a,b,c (float): coefficients for the ellipse
        
        Returns:
            float: Intensity value at (x,y) following the curve
        """
        return self.gauss(amp=amp, bg=bg, muX=muX, muY=muY, a=a, b=b, c=c)(x)

    def fitCurve(
        self,
        amp: float,
        bg: float,
        mu: list,
        sigma: list,
        coords: np.ndarray,
        psf: np.ndarray,
    ):
        """Fits a 2D Ellipse Gaussian curve to the provided PSF data using the given initial parameters and coordinates.
        
        Args:
            amp (float): amplitude of the Gaussian
            bg (float): background intensity
            mu (List(float)): center of the Gaussian
            sigma (List(float)): standard deviation of the Gaussian
            coords (np.array(float)): List of X,Y coordinates
            psf (np.ndarray): 1D image of the flatten 2D psf
        
        Raises:
            RuntimeError: If the optimization fails to converge.
        
        Returns:
            List(float),Matrix(float): List of fitted parameters and covariance matrix
        """
        params = [amp, bg, *mu, *sigma]
        try:
            popt, pcov = curve_fit(
                self.evalFun,
                coords,
                psf.ravel(),
                p0=params,
                maxfev=20000,
                bounds=(
                    [0, -np.inf, 0, 0, -1e-6, -1e-6, -1e-6],
                    [np.inf, np.inf, psf.shape[0], psf.shape[1], np.inf, np.inf, np.pi],
                ),
            )
        except Exception as e:
            print(
                f"Fitting2DEllips Optimization warning: {e}. Returning initial parameters."
            )
            popt = params
            pcov = np.zeros((len(params), len(params)))
            self._commentary += f"Fitting2DEllips Optimization warning. Returning initial parameters (Fitting1D).\n"
        return popt, pcov

    def ellipseParmConversion(self, a: float, b: float, c: float):
        """Converts the parameters of a 2D Ellipse Gaussian fit (a, b, c) into the angle of rotation (theta) and the standard deviations along the major and minor axes (sx, sy).
        
        Args:
            a (float): coefficient for the ellipse linked to the x-axis
            b (float): coefficient for the ellipse linked to the interaction between x and y
            c (float): coefficient for the ellipse linked to the y-axis
        
        Returns:
            tuple: The angle of rotation (theta) and the standard deviations along the major and minor axes (sx, sy)
        """
        t = math.sqrt(4.0 * (b**2) + ((a - c) ** 2))
        s = math.sqrt(abs((b**2) - (a * c)))
        sx = math.sqrt(abs(-a + t - c)) / 2.0 / s
        sy = math.sqrt(abs(-a - t - c)) / 2.0 / s
        theta = (math.sqrt(1.0 + ((a - c) / t)) if t != 0 else 0) / math.sqrt(2.0)
        theta = math.acos(theta)
        thetaSign = (
            (4 * b * (sx**2) * (sy**2) / ((sx**2) - (sy**2)))
            if (sx**2) != (sy**2)
            else 0
        )
        thetaSign = max(-1.0, min(1.0, thetaSign))
        thetaSign = np.sign(-0.5 * math.asin(thetaSign))
        theta = ((math.pi / 2) - theta) * thetaSign
        return theta, sx, sy

    def showFit(self, outputPath: str):
        """Plots the fitted 2D Ellipse Gaussian curve against the original PSF data for all three axes.
        
        Args:
            outputPath (str): Directory where the plots will be saved.
        """
        fitShapeZ = min(self._image.shape[0] * 5, 256)
        fitShapeY = min(self._image.shape[1] * 5, 128)
        fitShapeX = min(self._image.shape[2] * 5, 128)
        self.showSingleFit(
            self.psf[1],
            os.path.join(outputPath, "2D_Gaussian_Image_YX.png"),
            self.params2D[1],
            self.thetas[1],
            f"Fit YX - angle {self.thetas[0]:.2f} rad",
            fitPSFShape=(fitShapeY, fitShapeX),
        )
        self.showSingleFit(
            self.psf[2],
            os.path.join(outputPath, "2D_Gaussian_Image_XZ.png"),
            self.params2D[2],
            self.thetas[2],
            f"Fit XZ - angle {self.thetas[1]:.2f} rad",
            fitPSFShape=(fitShapeZ, fitShapeX),
        )
        self.showSingleFit(
            self.psf[0],
            os.path.join(outputPath, "2D_Gaussian_Image_ZY.png"),
            self.params2D[0],
            self.thetas[0],
            f"Fit ZY - angle {self.thetas[2]:.2f} rad",
            fitPSFShape=(fitShapeZ, fitShapeY),
        )

    def showSingleFit(
        self,
        psf: np.ndarray,
        outputPath: str,
        params,
        theta,
        title: str,
        fitPSFShape=None,
    ):
        """Generates and saves a plot comparing the original PSF data with the fitted 2D Ellipse Gaussian curve, including the center of the Gaussian (mu) and the angle of rotation (theta).
        
        Args:
            psf (np.ndarray): The original PSF data.
            outputPath (str): The path where the plot will be saved.
            params: The parameters for the 2D Ellipse Gaussian curve.
            theta: The angle of rotation.
            title (str): The title for the plot.
            fitPSFShape (tuple, optional): The shape of the fitted PSF data. Defaults to None.
        """
        if fitPSFShape is None:
            fitPSFShape = psf.shape
        yyFine = np.linspace(0, psf.shape[0], fitPSFShape[0])
        xxFine = np.linspace(0, psf.shape[1], fitPSFShape[1])
        yFine, xFine = np.meshgrid(yyFine, xxFine, indexing="ij")
        fineCoords = np.stack([yFine.ravel(), xFine.ravel()], -1)

        fit = self.gauss(*params)(fineCoords).reshape(fitPSFShape[0], fitPSFShape[1])

        y0 = params[2] * fitPSFShape[0] / psf.shape[0]
        x0 = params[3] * fitPSFShape[1] / psf.shape[1]
        L = min(max(fitPSFShape) * 5 / 4, 30)

        if params[4] > params[5]:
            dy = L * np.cos(theta)
            dx = -L * np.sin(theta)
        else:
            dy = L * np.sin(theta)
            dx = L * np.cos(theta)
        fig, ax = plt.subplots(figsize=(5, 5))
        ax.imshow(fit, cmap="viridis", origin="upper")
        ax.plot([x0 - dx, x0 + dx], [y0 - dy, y0 + dy], color="red", linewidth=2)
        ax.scatter([x0], [y0], color="red", alpha=0.7)
        ax.axhline(y=fitPSFShape[0] / 2, color="k", alpha=0.5, linestyle="--")
        ax.axvline(x=fitPSFShape[1] / 2, color="k", alpha=0.5, linestyle="--")
        ax.axis("off")
        ax.xaxis.set_inverted(True)
        ax.set_title(title)
        plt.tight_layout()
        fig.savefig(outputPath, dpi=300, bbox_inches="tight")
        plt.close(fig)

    def plotSingleFit(
        self,
        psf: np.ndarray,
        fineCoords: np.ndarray,
        fit2D: np.ndarray,
        outputPath: str,
        mu: float,
        index: int,
    ):
        """Generates and saves a plot comparing the original PSF data with the fitted 1D Gaussian curve and the 2D Ellipse Gaussian curve, including the center of the Gaussian (mu) and the FWHM for both fits.
        
        Args:
            psf (np.ndarray): The original PSF data.
            fineCoords (np.ndarray): The coordinates for the fine grid.
            fit2D (np.ndarray): The 2D Ellipse Gaussian fit.
            outputPath (str): The path where the visualization will be saved.
            mu (float): The center of the Gaussian.
            index (int): The index of the axis along which to compare profiles.
        """
        params = [
            self.params1D[0],
            self.params1D[1],
            self.params1D[2 + index],
            self.params1D[5 + index],
        ]
        fit1D = Fitting1D().gauss(*params)(fineCoords)
        coords = np.arange(self._image.shape[index])
        yLim = [0.0, psf.max() * 1.1]
        fig1, ax1 = plt.subplots(figsize=(7, 5))
        ax1.plot(coords, psf, "-", label="PSF", color="k")
        ax1.scatter(coords, psf, color="k", alpha=0.5, label="measurement points")
        ax1.plot(fineCoords, fit1D, label="1D Curve Fit")
        halfMax = (fit1D.max() + fit1D.min()) / 2.0
        ax1.axhline(
            y=halfMax, color="g", linestyle="--", alpha=0.7, label="FWHM 1D fit"
        )
        ax1.plot(fineCoords, fit2D, label="2D Curve Fit")
        halfMax = (fit2D.max() + fit2D.min()) / 2.0
        ax1.axhline(
            y=halfMax, color="r", linestyle="--", alpha=0.7, label="FWHM 2D fit"
        )
        ax1.axhline(
            y=self.parameters[0],
            color="orange",
            linestyle="dotted",
            alpha=0.5,
            label=f"Amplitude: {self.parameters[0]:.2f}",
        )
        ax1.axvline(
            x=mu,
            color="purple",
            linestyle="dotted",
            alpha=0.5,
            label=f"Mu: {self.parameters[2 + index]:.2f}",
        )
        ax1.plot(mu, self.parameters[0], "ko")
        ax1.set_ylim(yLim)
        ax1.set_title(f"{self.axes[index]} Profile")
        ax1.legend()
        ax1.set_xlabel("pixel")
        ax1.set_ylabel("Intensity")
        fig1.savefig(
            os.path.join(outputPath, f"fit_curve_1D_{self.axes[index]}.png"),
            dpi=300,
            bbox_inches="tight",
        )
        plt.close(fig1)

    def plotFit(self, outputPath: str):
        """Generates and saves a 3D plot comparing the original PSF data with the fitted 2D Ellipse Gaussian curve, including the center of the Gaussian (mu) and the angle of rotation (theta).
        
        Args:
            outputPath (str): The path where the visualization will be saved.
        """
        psf = self._image.astype(np.float64)
        center = self.getLocalCentroid()
        psfs = [
            psf[:, center[1], center[2]],
            psf[center[0], :, center[2]],
            psf[center[0], center[1], :],
        ]
        for i in range(3):
            fine = np.linspace(0, psf.shape[i] - 1, 100)
            if i < 2:
                index = i + 1
                fineCoords = np.column_stack((fine, np.full_like(fine, center[index])))
                mu = self.params2D[i][2]
            else:
                index = 0
                fineCoords = np.column_stack((np.full_like(fine, center[index]), fine))
                mu = self.params2D[i][3]
            self.plotSingleFit(
                psfs[i],
                fine,
                self.gauss(*self.params2D[i])(fineCoords),
                outputPath,
                mu,
                i,
            )

    def getCoords(self, psf: np.ndarray):
        """Generates a list of coordinates for the 2D fit based on the shape of the provided PSF image.
        
        Args:
            psf (np.ndarray): The PSF image for which to generate the coordinates.
        
        Returns:
            np.ndarray: A list of coordinates corresponding to the shape of the PSF image, suitable for use in the 2D fitting process.
        """
        y, x = np.indices(psf.shape)
        return np.stack([y.ravel(), x.ravel()], axis=-1)

    def processSingleFit(self, index: int):
        """Processes a single fit for the given index, performing fitting, and plotting.
        
        Args:
            index (int): ID of the PSF.
        """
        imageFloat = self._image.astype(np.float64)
        physic = self.getLocalCentroid()
        self.psf = [
            imageFloat[:, :, physic[2]],
            imageFloat[physic[0], :, :],
            imageFloat[:, physic[1], :],
        ]
        axe = ["ZY", "YX", "XZ"]
        coords = [
            self.getCoords(self.psf[0]),
            self.getCoords(self.psf[1]),
            self.getCoords(self.psf[2]),
        ]
        self.compute1DParams()
        self.params2D = []
        amp = self.params1D[0]
        bg = self.params1D[1]

        for u in range(3):
            u2 = (u + 1) % 3
            if u < 2:
                mu = [self.params1D[2 + u], self.params1D[2 + u2]]
            else:
                mu = [self.params1D[u2 + 2], self.params1D[u + 2]]
            sigma = [1, 0, 1]

            params, pcov = self.fitCurve(amp, bg, mu, sigma, coords[u], self.psf[u])

            self.params2D.append(params)
            theta, s1, s2 = self.ellipseParmConversion(params[4], params[5], params[6])
            self.thetas[u] = theta
            self.parameters[0] += params[0] / 3.0
            self.parameters[1] += params[1] / 3.0

            if u < 2:
                self.parameters[2 + u] += params[2] / 2.0
                self.parameters[2 + u2] += params[3] / 2.0
                self.parameters[5 + u] += s1 / 2.0
                self.parameters[5 + u2] += s2 / 2.0
                self.fwhms[u] += pxToUm(self.fwhm(s1), self._spacing[u]) / 2.0
                self.fwhms[u2] += pxToUm(self.fwhm(s2), self._spacing[u2]) / 2.0
            else:
                self.parameters[2 + u] += params[3] / 2.0
                self.parameters[2 + u2] += params[2] / 2.0
                self.parameters[5 + u] += s2 / 2.0
                self.parameters[5 + u2] += s1 / 2.0
                self.fwhms[u] += pxToUm(self.fwhm(s1), self._spacing[u]) / 2.0
                self.fwhms[u2] += pxToUm(self.fwhm(s2), self._spacing[u2]) / 2.0

            self.uncertainties[u] = self.uncertainty(pcov)
            self.determinations[u] = self.determination(
                params, coords[u], self.psf[u].flatten()
            )
            self.pcovs[u] = pcov
        self.activePath = self.getActivePath(index)
