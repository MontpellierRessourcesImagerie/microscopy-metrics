import math
import os
import numpy as np
import matplotlib
import warnings

matplotlib.use("Agg")
from matplotlib import pyplot as plt

from scipy.optimize import curve_fit, OptimizeWarning
from scipy.spatial.transform import Rotation as SciRot

from microscopy_metrics.fittingTools.fittingTool import FittingTool
from microscopy_metrics.fittingTools.fitting1D import Fitting1D
from microscopy_metrics.utils import pxToUm

warnings.filterwarnings("error", category=OptimizeWarning)


class Fitting3DRotation(FittingTool):
    """Class for fitting a 3D Gaussian curve with rotation to the PSF profile of a microscopy image.
    This class inherits from the FittingTool base class and implements methods specific to 3D Gaussian fitting with rotation.
    It includes methods for evaluating the Gaussian function, fitting the curve to the data, and plotting the results.
    """

    name = "3D Rotation"

    def __init__(self):
        super().__init__()
        self.thetas = [0, 0, 0]

    def gauss(
        self,
        amp: float,
        bg: float,
        muZ: float,
        muY: float,
        muX: float,
        sigmaZ: float,
        sigmaY: float,
        sigmaX: float,
        thetaZ: float,
        thetaY: float,
        thetaX: float,
    ):
        """Generates a 3D Gaussian function with rotation based on the provided parameters.

        Args:
            amp (float): Amplitude of the curve.
            bg (float): Background intensity.
            muZ (float): Center coordinate of the Gaussian along the Z-axis.
            muY (float): Center coordinate of the Gaussian along the Y-axis.
            muX (float): Center coordinate of the Gaussian along the X-axis.
            sigmaZ (float): Standard deviation of the Gaussian along the Z-axis.
            sigmaY (float): Standard deviation of the Gaussian along the Y-axis.
            sigmaX (float): Standard deviation of the Gaussian along the X-axis.
            thetaZ (float): Rotation angle around the Z-axis (in radians).
            thetaY (float): Rotation angle around the Y-axis (in radians).
            thetaX (float): Rotation angle around the X-axis (in radians).

        Returns:
            float: Intensity value at (x, y, z) following the curve.
        """

        def fun(coords: np.ndarray):
            z = coords[:, 0] - muZ
            y = coords[:, 1] - muY
            x = coords[:, 2] - muX
            cx, sx = np.cos(thetaX), np.sin(thetaX)
            cy, sy = np.cos(thetaY), np.sin(thetaY)
            cz, sz = np.cos(thetaZ), np.sin(thetaZ)
            x_rot = (
                (cy * cz) * x
                + (cz * sx * sy - cx * sz) * y
                + (cx * cz * sy + sx * sz) * z
            )
            y_rot = (
                (cy * sz) * x
                + (cx * cz + sx * sy * sz) * y
                + (-cz * sx + cx * sy * sz) * z
            )
            z_rot = (-sy) * x + (cy * sx) * y + (cy * cx) * z
            exponent = (
                -(x_rot**2) / (2 * sigmaX**2)
                - (y_rot**2) / (2 * sigmaY**2)
                - (z_rot**2) / (2 * sigmaZ**2)
            )
            return bg + (amp - bg) * np.exp(exponent)

        return fun

    def evalFun(
        self,
        x: np.ndarray,
        amp: float,
        bg: float,
        muZ: float,
        muY: float,
        muX: float,
        sigmaZ: float,
        sigmaY: float,
        sigmaX: float,
        thetaZ: float,
        thetaY: float,
        thetaX: float,
    ):
        """Evaluates the 3D Gaussian function with rotation at the given x values.
        
        Args:
            amp (float): amplitude of the curve
            bg (float): background intensity
            muZ,muY,muX (float): center coordinates of the Gaussian
            sigmaZ (float): standard deviation of the Gaussian along the Z-axis
            sigmaY (float): standard deviation of the Gaussian along the Y-axis
            sigmaX (float): standard deviation of the Gaussian along the X-axis
            thetaZ (float): rotation angle around the Z-axis (in radians)
            thetaY (float): rotation angle around the Y-axis (in radians)
            thetaX (float): rotation angle around the X-axis (in radians)

        Returns:
            float: Intensity value at (x,y,z) following the curve
        """
        return self.gauss(
            amp=amp,
            bg=bg,
            muZ=muZ,
            muY=muY,
            muX=muX,
            sigmaZ=sigmaZ,
            sigmaY=sigmaY,
            sigmaX=sigmaX,
            thetaZ=thetaZ,
            thetaY=thetaY,
            thetaX=thetaX,
        )(x)

    def fitCurve(
        self,
        amp: float,
        bg: float,
        mu: list,
        sigma: list,
        coords: np.ndarray,
        psf: np.ndarray,
    ):
        """Fits a 3D Gaussian curve with rotation to the provided PSF data.
        
        Args:
            amp (float): amplitude of the Gaussian
            bg (float): background intensity
            mu (list): center of the Gaussian
            sigma (list): standard deviation of the Gaussian
            coords (np.array(float)): List of X,Y,Z coordinates
            psf (np.ndarray): 1D image of the flatten 2D psf
        
        Raises:
            RuntimeError: If the optimization fails to converge
        
        Returns:
            list,Matrix(float): List of fitted parameters and covariance matrix
        """
        params = [amp, bg, *mu, *sigma, 0, 0, 0]
        bounds = (
            [0, -np.inf, 0, 0, 0, 1e-6, 1e-6, 1e-6, -np.pi, -np.pi, -np.pi],
            [
                np.inf,
                np.inf,
                psf.shape[0],
                psf.shape[1],
                psf.shape[2],
                np.inf,
                np.inf,
                np.inf,
                np.pi,
                np.pi,
                np.pi,
            ],
        )
        try:
            popt, pcov = curve_fit(
                self.evalFun,
                coords,
                psf.ravel(),
                p0=params,
                maxfev=20000,
                bounds=bounds,
            )
        except Exception as e:
            print(
                f"Fitting3DRotation Optimization warning: {e}. Returning initial parameters."
            )
            popt = params
            pcov = np.zeros((len(params), len(params)))
            self._commentary += f"Fitting3DRotation Optimization warning. Returning initial parameters (Fitting1D).\n"
        return popt, pcov

    def showFit(self, outputPath: str):
        """Plots the fitted 3D Gaussian curve with rotation against the original PSF data for all three axes.
        
        Args:
            outputPath (str): Directory where the plots will be saved.
        """
        center = self.getLocalCentroid()
        psf = self._image.astype(np.float64)
        fitShapeZ = min(psf.shape[0] * 5, 256)
        fitShapeY = min(psf.shape[1] * 5, 128)
        fitShapeX = min(psf.shape[2] * 5, 128)
        zz_fine = np.linspace(0, psf.shape[0], fitShapeZ)
        yy_fine = np.linspace(0, psf.shape[1], fitShapeY)
        xx_fine = np.linspace(0, psf.shape[2], fitShapeX)
        z_fine, y_fine, x_fine = np.meshgrid(zz_fine, yy_fine, xx_fine, indexing="ij")
        fine_coords_zyx = np.stack([z_fine.ravel(), y_fine.ravel(), x_fine.ravel()], -1)
        z0 = self.parameters[2] * (fitShapeZ / psf.shape[0])
        y0 = self.parameters[3] * (fitShapeY / psf.shape[1])
        x0 = self.parameters[4] * (fitShapeX / psf.shape[2])
        L = min(max(psf.shape) * 5 / 4, 30)
        thetaX = self.thetas[2]
        thetaY = self.thetas[1]
        thetaZ = self.thetas[0]
        rot = SciRot.from_euler("zyx", [thetaZ, thetaY, thetaX])
        R = rot.as_matrix()
        sigma2 = np.diag(
            [self.parameters[7] ** 2, self.parameters[6] ** 2, self.parameters[5] ** 2]
        )
        cov = R @ sigma2 @ R.T
        eigvals, eigvecs = np.linalg.eigh(cov)
        majorIDX = np.argmax(eigvals)
        majorAxis = eigvecs[:, majorIDX]
        anisotropy = np.sqrt(eigvals[majorIDX] / np.min(eigvals))
        hasMajorAxis = anisotropy > 1.15
        L = min(max(psf.shape) * 5 / 4, 30)
        params = [*self.parameters, *self.thetas]
        fit = self.gauss(*params)(fine_coords_zyx)
        fit = fit.reshape((fitShapeZ, fitShapeY, fitShapeX))
        fig = plt.figure(figsize=(10, 5))
        ax2 = fig.add_subplot(1, 2, 2)
        centerFit = int(fitShapeZ * (center[0] / psf.shape[0]))
        ax2.imshow(fit[centerFit], cmap="viridis", origin="upper")
        ax2.set_title(f"Fit YX - angle {self.thetas[0]:.2f} rad")
        ax2.axis("off")
        proj_yx = np.array([majorAxis[0], majorAxis[1]])
        norm_yx = np.linalg.norm(proj_yx)
        if hasMajorAxis and norm_yx > 1e-6:
            dir_yx = proj_yx / norm_yx
            dx_yx, dy_yx = L * dir_yx
            ax2.plot(
                [x0 - dx_yx, x0 + dx_yx],
                [y0 - dy_yx, y0 + dy_yx],
                color="red",
                linewidth=2,
            )
            ax2.scatter([x0], [y0], color="red", alpha=0.7)
        ax2.axhline(y=fitShapeY / 2, color="k", alpha=0.5, linestyle="--")
        ax2.axvline(x=fitShapeX / 2, color="k", alpha=0.5, linestyle="--")
        ax2.xaxis.set_inverted(True)
        plt.tight_layout()
        fig.savefig(
            os.path.join(outputPath, "2D_Gaussian_Image_YX.png"),
            dpi=300,
            bbox_inches="tight",
        )
        plt.close(fig)
        fig2 = plt.figure(figsize=(10, 5))
        ax2 = fig2.add_subplot(1, 2, 2)
        centerFit = int(fitShapeY * (center[1] / psf.shape[1]))
        ax2.imshow(fit[:, centerFit, :], cmap="viridis", origin="upper")
        ax2.set_title(f"Fit XZ - Pitch: {self.thetas[1]:.2f} rad")
        proj_xz = np.array([majorAxis[0], majorAxis[2]])
        norm_xz = np.linalg.norm(proj_xz)
        if hasMajorAxis and norm_xz > 1e-6:
            dir_xz = proj_xz / norm_xz
            dx_xz, dz_xz = L * dir_xz
            ax2.plot(
                [x0 - dx_xz, x0 + dx_xz],
                [z0 - dz_xz, z0 + dz_xz],
                color="red",
                linewidth=2,
            )
        ax2.scatter([x0], [z0], color="red", alpha=0.7)
        ax2.axhline(y=fitShapeZ / 2, color="k", alpha=0.5, linestyle="--")
        ax2.axvline(x=fitShapeX / 2, color="k", alpha=0.5, linestyle="--")
        ax2.xaxis.set_inverted(True)
        ax2.axis("off")
        plt.tight_layout()
        fig2.savefig(
            os.path.join(outputPath, "2D_Gaussian_Image_XZ.png"),
            dpi=300,
            bbox_inches="tight",
        )
        plt.close(fig2)
        fig3 = plt.figure(figsize=(10, 5))
        ax2 = fig3.add_subplot(1, 2, 2)
        centerFit = int(fitShapeX * (center[2] / psf.shape[2]))
        ax2.imshow(fit[:, :, centerFit], cmap="viridis", origin="upper")
        ax2.set_title(f"Fit ZY - Roll: {self.thetas[2]:.2f} rad")
        proj_zy = np.array([majorAxis[1], majorAxis[2]])
        norm_zy = np.linalg.norm(proj_zy)
        if hasMajorAxis and norm_zy > 1e-6:
            dir_zy = proj_zy / norm_zy
            dy_zy, dz_zy = L * dir_zy
            ax2.plot(
                [y0 - dy_zy, y0 + dy_zy],
                [z0 + dz_zy, z0 - dz_zy],
                color="red",
                linewidth=2,
            )
        ax2.scatter([y0], [z0], color="red", alpha=0.7)
        ax2.axhline(y=fitShapeZ / 2, color="k", alpha=0.5, linestyle="--")
        ax2.axvline(x=fitShapeY / 2, color="k", alpha=0.5, linestyle="--")
        ax2.axis("off")
        ax2.xaxis.set_inverted(True)
        plt.tight_layout()
        fig3.savefig(
            os.path.join(outputPath, "2D_Gaussian_Image_ZY.png"),
            dpi=300,
            bbox_inches="tight",
        )
        plt.close(fig3)

    def plotSingleFit(
        self,
        coords: np.ndarray,
        psf: np.ndarray,
        fineCoords: np.ndarray,
        fit3D: np.ndarray,
        outputPath: str,
        index: int,
    ):
        """Plots the fitted 3D Gaussian curve with rotation against the original PSF data for a single axis.
        
        Args:
            coords (np.ndarray): Coordinates of the data points along the axis being plotted.
            psf (np.ndarray): Intensity values at the data points along the axis being plotted.
            fineCoords (np.ndarray): Coordinates for plotting the fitted curve along the axis being plotted.
            fit3D (np.ndarray): Intensity values of the fitted 3D Gaussian curve with rotation along the axis being plotted.
            outputPath (str): Directory where the plot will be saved.
            index (int): Index of the axis being plotted (0 for Z, 1 for Y, 2 for X).
        """
        params = [
            self.params1D[0],
            self.params1D[1],
            self.params1D[2 + index],
            self.params1D[5 + index],
        ]
        fit1D = Fitting1D().gauss(*params)(fineCoords)
        yLim = [0.0, psf.max() * 1.1]
        fig1, ax1 = plt.subplots(figsize=(7, 5))
        ax1.plot(coords, psf, "-", label="PSF", color="k")
        ax1.scatter(coords, psf, color="k", alpha=0.5, label="measurement points")
        ax1.plot(fineCoords, fit1D, label="1D Curve Fit")
        halfMax = (fit1D.max() + fit1D.min()) / 2.0
        ax1.axhline(
            y=halfMax, color="g", linestyle="--", alpha=0.7, label="FWHM 1D fit"
        )
        ax1.plot(fineCoords, fit3D, label="3D Curve Fit")
        halfMax = (fit3D.max() + fit3D.min()) / 2.0
        ax1.axhline(
            y=halfMax, color="r", linestyle="--", alpha=0.7, label="FWHM 3D fit"
        )
        ax1.axhline(
            y=self.parameters[0],
            color="orange",
            linestyle="dotted",
            alpha=0.5,
            label=f"Amplitude: {self.parameters[0]:.2f}",
        )
        ax1.axvline(
            x=self.parameters[2 + index],
            color="purple",
            linestyle="dotted",
            alpha=0.5,
            label=f"Mu: {self.parameters[2 + index]:.2f}",
        )
        ax1.plot(self.parameters[2 + index], self.parameters[0], "ko")
        ax1.set_ylim(yLim)
        ax1.set_title(f"{self.axes[index]} Profile")
        ax1.legend()
        ax1.set_xlabel("pixel")
        ax1.set_ylabel("Intensity")
        fig1.savefig(
            os.path.join(outputPath, f"fit_curve_1D_{self.axes[index]}.png"),
            dpi=300,
            bbox_inches="tight",
        )
        plt.close(fig1)

    def plotFit(self, outputPath: str):
        """Plots the fitted 3D Gaussian curve with rotation against the original PSF data for all three axes.
        
        Args:
            outputPath (str): Directory where the plots will be saved.
        """
        psf = self._image.astype(np.float64)
        center = self.getLocalCentroid()
        psfs = [
            psf[:, center[1], center[2]],
            psf[center[0], :, center[2]],
            psf[center[0], center[1], :],
        ]
        for i in range(3):
            coords = np.arange(psf.shape[i])
            fine = np.linspace(0, psf.shape[i] - 1, 100)

            fineCoords = np.full((100, 3), center, dtype=np.float64)
            fineCoords[:, i] = fine

            params = [*self.parameters, *self.thetas]
            self.plotSingleFit(
                coords,
                psfs[i],
                fine,
                self.gauss(*params)(fineCoords),
                outputPath,
                i,
            )

    def getCoords(self, psf: np.ndarray):
        """Generates an array of coordinates corresponding to the length of the PSF profile for 3D fitting.
        
        Args:
            psf (np.ndarray): 3D image to process
        
        Returns:
            np.ndarray: Coordinates for the 3D fit
        """
        z, y, x = np.indices(psf.shape)
        return np.stack([z.ravel(), y.ravel(), x.ravel()], axis=-1)

    def processSingleFit(self, index: int):
        """Processes a single fit for the given index, performing fitting, plotting, and calculating metrics.
        
        Args:
            index (int): ID of the PSF and position in lists for which to perform the fit.
        
        Returns:
            List(parameters): A list containing metrics, fwhm, parameters and covariance matrix of the fit.
        """
        psf = self._image.astype(np.float64)
        self.coords = self.getCoords(psf)
        self.compute1DParams()
        bg = self.params1D[1]
        amp = self.params1D[0]
        mu = [self.params1D[2], self.params1D[3], self.params1D[4]]
        sigma = [self.params1D[5], self.params1D[6], self.params1D[7]]
        params, pcov = self.fitCurve(amp, bg, mu, sigma, self.coords, psf)
        self.thetas = params[8:11]
        self.parameters[0] = params[0]
        self.parameters[1] = params[1]
        self.parameters[2:5] = params[2:5]
        self.parameters[5:8] = params[5:8]
        self.pcovs = [pcov] * 3
        self.activePath = self.getActivePath(index)
        self.fwhms = [
            pxToUm(self.fwhm(self.parameters[5]), self._spacing[0]),
            pxToUm(self.fwhm(self.parameters[6]), self._spacing[1]),
            pxToUm(self.fwhm(self.parameters[7]), self._spacing[2]),
        ]
        self.uncertainties = [self.uncertainty(pcov)] * 3
        self.determinations = [
            self.determination(
                [*self.parameters, *self.thetas], self.coords, psf.flatten()
            )
        ] * 3
        self.pcovs = [pcov] * 3
